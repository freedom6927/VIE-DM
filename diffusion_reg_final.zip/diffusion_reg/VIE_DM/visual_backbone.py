from functools import partial

from einops.einops import rearrange,repeat
from torch import nn
import argparse
import os
import warnings
import pdb
from mmcv import Config, DictAction
from mmcv.runner import  load_checkpoint
import sys
sys.path.insert(0,'models/swin_model')
from mmdet.models import build_detector
from icecream import ic
import torch
#from models.trans_vg import MuModule


class Swin(nn.Module):
    def __init__(self) -> None:
        super(Swin,self).__init__()
        #self.args=args
        self.flag=None
        config='models/swin_model/configs/my_config/simple_multimodal_fpn_config.py'
        self.flag='multi-modal'
        cfg_options=None
        #pdb.set_trace()
        checkpoint='./pre_trained_models/cascade_mask_rcnn_swin_tiny_patch4_window7.pth'
        cfg = Config.fromfile(config)
        if cfg_options is not None:
            cfg.merge_from_dict(cfg_options)
        if cfg.get('custom_imports', None):
            from mmcv.utils import import_modules_from_strings
            import_modules_from_strings(**cfg['custom_imports'])
        cfg.model.neck.type = 'NoFpnSoftDownSample'
        cfg.model.backbone.use_spatial = True
        cfg.model.backbone.use_channel = True
        cfg.model.neck.use_spatial = True
        cfg.model.neck.use_channel= True
     
        self.cfg=cfg
        model = build_detector(
            cfg.model,
            train_cfg=cfg.get('train_cfg'),
            test_cfg=cfg.get('test_cfg'))
        checkpoint = load_checkpoint(model, checkpoint, map_location='cpu')
        self.pretrained_parameter_name=checkpoint.keys()  
        
        self.num_channels=cfg.model['neck']['out_channels']
        self.backbone=model.backbone
        self.neck=model.neck    
        self.rpn_head=model.rpn_head

    
    def forward(self,image, image_mask, text=None,extra:dict=None):
        import torch.nn.functional as F
        """Directly extract features from the backbone+neck."""
        #pdb.set_trace()
        img = image[0]
        img_region = image[1]
        mask = image_mask[0]
        mask_region = image_mask[1]
        #image
        x = self.backbone(img,text)
        x = self.neck(x,text)
        out_mask=[F.interpolate(mask[None].float(), size=_.shape[-2:]).to(torch.bool)[0] for _ in x]
        # flatten
        #pdb.set_trace()
        #shape=[_.shape[-2:] for _ in x] 
        x = [rearrange(_,'B C H W -> (H W) B C') for _ in x]
        out_mask = [rearrange(_,'B H W -> B (H W)') for _ in out_mask]

        #image_region
        x_region = self.backbone(img_region, text)
        x_region = self.neck(x_region, text)
        out_mask_region = [F.interpolate(mask_region[None].float(), size=_.shape[-2:]).to(torch.bool)[0] for _ in x]
        # flatten
        #pdb.set_trace()
        #shape=[_.shape[-2:] for _ in x_region] 
        x_region = [rearrange(_,'B C H W -> (H W) B C') for _ in x_region]
        out_mask_region = [rearrange(_,'B H W -> B (H W)') for _ in out_mask_region]
        
        return [x, x_region], [out_mask, out_mask_region]

if __name__=='__main__':
    pass
        
        

